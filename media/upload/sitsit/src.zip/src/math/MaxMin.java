package math;

//បរមា
public class MaxMin {

}
