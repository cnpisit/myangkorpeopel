package math;

public class Curve {

}
