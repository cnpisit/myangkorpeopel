package math;

import expr.Expression;
import parser.AllExpressionParser;
import parser.compound.binary.AddExpressionParser;
import parser.compound.binary.DivExpressionParser;
import parser.compound.binary.LogarithmExpressionParser;
import parser.compound.binary.MulExpressionParser;
import parser.compound.binary.PowerExpressionParser;
import parser.compound.binary.SubExpressionParser;
import parser.simple.ConstantExpressionParser;
import parser.simple.ExpoBaseEExpressionParser;
import parser.simple.LogarithmNaturalExpressionParser;
import parser.simple.XExpressionParser;
import parser.simple.triangle.CosExpressionParser;
import parser.simple.triangle.CotExpressionParser;
import parser.simple.triangle.SinExpressionParser;
import parser.simple.triangle.TanExpressionParser;

public class ExpressionTools {

	public static AllExpressionParser ep = AllExpressionParser.instance;
	public static boolean initialized = false ;

	public static void initializeParser() {
		ep.addParser(AddExpressionParser.instance);
		ep.addParser(SubExpressionParser.instance);
		ep.addParser(MulExpressionParser.instance);
		ep.addParser(DivExpressionParser.instance);
		ep.addParser(PowerExpressionParser.instance);
		ep.addParser(XExpressionParser.instance);
		ep.addParser(ConstantExpressionParser.instance);
		ep.addParser(LogarithmExpressionParser.instance);
		ep.addParser(ExpoBaseEExpressionParser.instance);
		ep.addParser(LogarithmNaturalExpressionParser.instance);
		ep.addParser(CosExpressionParser.instance);
		ep.addParser(CotExpressionParser.instance);
		ep.addParser(SinExpressionParser.instance);
		ep.addParser(TanExpressionParser.instance);
		
		initialized = true ;
	}
	
	public static Expression parseExpression(String s){
		if( !initialized )
			initializeParser() ;
		
		return ep.parseExpression(s) ;
	}

}
