/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package math;

import java.util.ArrayList;

import expr.Expression;

/**
 *
 * @author Administratorvb          
 */
public class Domain {
	Expression e;
	private static String D;
	static double d[];
	
    
    public Domain(Expression e){
        this.e=e;
    }
    
    public String functionType(Expression e){
       	return null;
    }
    
    public static double[] getDomain(Polynomial e){
    	
    		d=e.roots();
   	    	    
    	if(d.length==2){
    		return new double[]{ d[1]};
    		    		
    	}
    	else if(d.length==3){
    		
    		return new double[]{d[1],d[2]};
    	}
    	else if(d.length==4){
    		
    		return new double[]{d[1],d[2],d[3]};
    	}
		return null;
    }
    
  
    
    
    public static void main(String[] args) {
    	//-2x^2+2x+5
    	// 
    	
    	/*Expression e = new AddExpression(new ConstantExpression(2), new XExpression());
    	
    	e = new AddExpression(new ConstantExpression(5)
    		, new AddExpression(
    				new MulExpression(new ConstantExpression(-2), 
    						new PowerExpression(new XExpression(), new ConstantExpression(2)))
    				, new MulExpression(new ConstantExpression(2), new XExpression())
    				) 
    	)
    	;
    	*/
    	
    	Polynomial p = new Polynomial( new double[]{ 0,2,3}) ;
    	
    	//System.out.println(e);
    	
    	System.out.println(p);
    	getDomain(p);
    	
	}

}
