package math;

public class Derivative {

}
