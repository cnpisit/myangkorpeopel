package math;

import expr.Expression;

public class Asymtote {
	
	private Expression asym1 = null ;
	private Expression asym2 = null ;
	
	
	public Expression getAsym1(){
		
		
		
		return asym1 ;
	}
	
	public Expression getAsym2(){
		
		
		
		return asym2 ;
	}
	
}
