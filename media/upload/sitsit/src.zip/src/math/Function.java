package math;

import expr.Expression;

public class Function {
	private Expression expression ;
	
	public Function(){
		
	}
	
}
