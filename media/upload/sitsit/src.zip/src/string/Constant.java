package string;

public class Constant {
	public static final int STRING_BUFFER_MAX_CAPACITY = 1024 * 100 ; // 100 KB
	public static final int STRING_BUFFER_NORMAL_CAPACITY = 1024 * 10 ; // 10 KB
}
