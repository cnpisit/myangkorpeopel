package string.domain;

import math.Domain;
import math.Polynomial;
import string.Constant;

public class DomainString {
	public static StringBuffer addStringToDomain(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		Polynomial p = new Polynomial( new double[]{ -4,3,3}) ;
		String D=null;//Domain
		double[] d;
		d=Domain.getDomain(p);
		if(d.length==1){
			D="D = R - { "+d[0]+" }";
		}
		
		else if(d.length==2){
			D="D = R - { "+d[0]+" , "+d[1]+" }";
		}
		
		else if(d.length==3){
			D="D = R - { "+d[0]+" , "+d[1]+" , "+d[2]+" }";
		}
		
		htmlString.append(D) ;
		//htmlString.append("change here go to string.domain.DomainString.addStringToDomain()" ) ;
		
		return htmlString ;
	}
//	public static void main(String args[]){
//		addStringToDomain();
//	}
}
