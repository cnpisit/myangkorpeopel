package string.direction;

import string.Constant;

public class ChangePointString {
	public static StringBuffer addStringToChangePoint(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		// TODO
		htmlString.append("change here go to string.direction.ChangePointString.addStringToChangePoint()") ;
		
		return htmlString ;
	}
}
