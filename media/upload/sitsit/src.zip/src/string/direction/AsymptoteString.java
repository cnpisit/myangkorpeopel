package string.direction;

import expr.Expression;
import string.Constant;

public class AsymptoteString {
	
	public static StringBuffer addStringToAsymptote(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		// TODO
		htmlString.append("change here go to string.direction.AsymtoteString.addStringToAsymtote()") ;
		htmlString.append(" hello ");
		
		
		return htmlString ;
	}
}
