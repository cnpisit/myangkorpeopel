package string.direction;

import string.Constant;


public class DirectionString {
	public static StringBuffer addStringToDirection(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		htmlString.append(DerivativeString.addStringToDrivative()) ;
		htmlString.append("<br />") ;
		
		htmlString.append(MaxMinString.addStringToMaxMin()) ;
		htmlString.append("<br />") ;
		
		htmlString.append(ChangePointString.addStringToChangePoint()) ;
		htmlString.append("<br />") ;
		
		htmlString.append(LimitString.addStringToLimit()) ;
		htmlString.append("<br />") ;
		
		htmlString.append(AsymptoteString.addStringToAsymptote()) ;
		htmlString.append("<br />") ;
		
		htmlString.append(VarianceTableString.addStringToVarianceTable()) ;
		htmlString.append("<br />") ;
		
		
		return htmlString ;
	}
}	
