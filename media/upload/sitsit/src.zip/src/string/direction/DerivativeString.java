package string.direction;

import string.Constant;

public class DerivativeString {
	public static StringBuffer addStringToDrivative(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		// TODO here
		htmlString.append("change here go to string.direction.DerivativeString.addStringToDerivative()") ;
		
		return htmlString ;
	}
}
