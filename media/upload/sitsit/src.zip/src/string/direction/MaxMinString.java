package string.direction;

import string.Constant;

public class MaxMinString {
	public static StringBuffer addStringToMaxMin(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		// TODO
		htmlString.append("change here go to string.direction.MaxMinString.addStringToMaxMin()") ;
		
		return htmlString ;
	}
}
