package string.direction;

import string.Constant;

public class LimitString {
	public static StringBuffer addStringToLimit(){
		StringBuffer htmlString = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		// TODO
		htmlString.append("change here go to string.direction.LimitString.addStringToLimit()") ;
		
		return htmlString ;
	}
}
