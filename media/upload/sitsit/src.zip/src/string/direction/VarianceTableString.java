package string.direction;

import math.Polynomial;

public class VarianceTableString {
	public static String addStringToVarianceTable(){
            Polynomial p1 = new Polynomial(new double[]{0 ,2}) ;
		
		System.out.println(p1);
		double[] rootP1 = p1.roots() ;
		
		System.out.println();
		for( double r : rootP1 ){
			System.out.println(r); 
		}
                
		String htmlString = "" ;
		htmlString += "<h2> 2 - 1 Variance Table</h2>" ;
		// TODO
		htmlString += "change here go to string.direction.VarianceTableString.addStringTOVarianceTable()" ;
		
		htmlString += "<table border=\"1\">" ;
		for(int r = 1 ;  r <= 3 ; r++){
			htmlString += "<tr>" ;
			for(int c = 1 ; c < 4 ; c++){
				htmlString += "<td>" ;
				htmlString += "r:" + r + "|c:" + c ; 
				htmlString += "</td>" ;
			}
			htmlString += "</tr>" ;
		}
		htmlString += "</table>" ;
		
		return htmlString ;
	}
}
