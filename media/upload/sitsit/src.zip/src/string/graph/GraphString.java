package string.graph;

import string.Constant;

public class GraphString {
	public static StringBuffer addStringToGraph(){
		StringBuffer htmlString  = new StringBuffer(Constant.STRING_BUFFER_NORMAL_CAPACITY) ;
		
		htmlString.append("change here go to string.graph.GraphString.addStringToGraph()") ;
		
		return htmlString ;
	}
}
