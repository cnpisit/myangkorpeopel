package main;

import math.Polynomial;
import expr.Expression;
import expr.compound.binary.AddExpression;
import expr.compound.binary.DivExpression;
import expr.simple.ConstantExpression;
import expr.simple.XExpression;

public class TestEx {
	public static void main(String[] args) {
		Expression e = new DivExpression(
				new ConstantExpression(3) ,
				new AddExpression(new XExpression(), new ConstantExpression(2))
) ;
		
		Polynomial p = new Polynomial(new double[]{2 , 1}) ;
		
		System.out.println(e);
		
		//e => p
		
		System.out.println(p);
		
		for ( double d : p.roots() ){
			System.out.println(d);
		}
	}
}
