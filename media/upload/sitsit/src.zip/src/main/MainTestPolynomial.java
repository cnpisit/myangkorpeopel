package main;

import math.Polynomial;

public class MainTestPolynomial {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Polynomial p1 = new Polynomial(new double[]{0 ,2}) ;
		
		System.out.println(p1);
		double[] rootP1 = p1.roots() ;
		
		System.out.println();
		for( double r : rootP1 ){
			System.out.println(r); 
		}
		
		System.out.println("---------------------------");

		
		Polynomial p2 = new Polynomial(new double[]{3.4,4,1}) ;
		System.out.println(p2);
		
		
		for(double r : p2.roots()){
			System.out.println(r);
		}
		
		System.out.println("---------------------------\n");
		
		Polynomial p3 = new Polynomial(new double[]{1,1,1}) ;
		System.out.println(p3);
		
		
		//-2 mean root complex real = 0.5 and img = 0.86
		for(double r : p3.roots()){
			System.out.println(r);
		}
		
		System.out.println("---------------------------\n");
		
	}

}
