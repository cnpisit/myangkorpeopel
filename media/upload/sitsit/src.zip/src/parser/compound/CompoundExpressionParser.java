package parser.compound;

import parser.ExpressionParser;

public abstract class CompoundExpressionParser implements ExpressionParser {

}
