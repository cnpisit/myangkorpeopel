package parser.simple.triangle;

import expr.Expression;
import expr.simple.triagle.CotExpression;
import parser.AllExpressionParser;
import parser.simple.SimpleExpressionParser;


public class CotExpressionParser extends SimpleExpressionParser{
    public static CotExpressionParser instance= new CotExpressionParser();
    @Override
    public Expression parseExpression(String exprStr) {
        int length = exprStr.length();
        
        if(exprStr.charAt(0)!='('||
            exprStr.charAt(1)!='c' || 
            exprStr.charAt(2)!='o'||
            exprStr.charAt(3)!='t' ||
            exprStr.charAt(4)!='('||
            exprStr.charAt(length-2)!=')'||
            exprStr.charAt(length-1)!=')') {
        	
            return null;
            
        }
        String c = exprStr.substring(4, length-1);
        Expression expr1 = AllExpressionParser.instance.parseExpression(c);
        try{
            return new CotExpression(expr1);
        }catch(NumberFormatException e){
            return null;
        }
    }
    private CotExpressionParser(){}
    
}
    
