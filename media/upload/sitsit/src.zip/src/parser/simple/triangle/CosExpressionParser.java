package parser.simple.triangle;

import expr.Expression;
import expr.simple.triagle.CosExpression;
import parser.AllExpressionParser;
import parser.simple.SimpleExpressionParser;

public class CosExpressionParser extends SimpleExpressionParser {
	public static CosExpressionParser instance = new CosExpressionParser();

	@Override
	public Expression parseExpression(String exprStr) {
		int length = exprStr.length();

		if (exprStr.charAt(0) != '(' 
				|| exprStr.charAt(1) != 'c'
				|| exprStr.charAt(2) != 'o' 
				|| exprStr.charAt(3) != 's'
				|| exprStr.charAt(4) != '('
				|| exprStr.charAt(length - 2) != ')'
				|| exprStr.charAt(length - 1) != ')') {
			return null;
		}
		String c = exprStr.substring(4, length - 1);
		Expression expr1 = AllExpressionParser.instance.parseExpression(c);
		try {
			return new CosExpression(expr1);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	private CosExpressionParser() {
	}

}
