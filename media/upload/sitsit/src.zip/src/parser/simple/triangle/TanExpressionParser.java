package parser.simple.triangle;

import expr.Expression;
import expr.simple.triagle.TanExpression;
import parser.AllExpressionParser;
import parser.simple.SimpleExpressionParser;

public class TanExpressionParser extends SimpleExpressionParser{
    public static TanExpressionParser instance= new TanExpressionParser();
    @Override
    public Expression parseExpression(String exprStr) {
        int length = exprStr.length();
        
        if(exprStr.charAt(0)!='('||
            exprStr.charAt(1)!='t'||exprStr.charAt(2)!='a'||exprStr.charAt(3)!='n' ||exprStr.charAt(4)!='('||exprStr.charAt(length-2)!=')'||exprStr.charAt(length-1)!=')') {
            return null;
        }
        String c = exprStr.substring(4, length-1);
        Expression expr1 = AllExpressionParser.instance.parseExpression(c);
        try{
            return new TanExpression(expr1);
        }catch(NumberFormatException e){
            return null;
        }
    }
    
    private TanExpressionParser(){}
}
