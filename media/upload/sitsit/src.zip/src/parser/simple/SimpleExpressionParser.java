package parser.simple;

import parser.ExpressionParser;

public abstract class SimpleExpressionParser implements ExpressionParser {

}
