package expr.simple;

import expr.Expression;

public abstract class SimpleExpression implements Expression {
}
