package expr.simple.triagle;

import expr.Expression;
import expr.compound.binary.AddExpression;
import expr.compound.binary.DivExpression;
import expr.compound.binary.MulExpression;
import expr.compound.binary.PowerExpression;
import expr.simple.ConstantExpression;
import expr.simple.SimpleExpression;

public class TanExpression extends SimpleExpression {
	Expression e;

	public TanExpression(Expression e) {
		this.e = e;
	}

	@Override
	public String toString() {
		return "tan(" + e + ")";
	}

	@Override
	public Expression simplify() {
		return new TanExpression(e.simplify());
	}

//	@Override
//	public double CalculerExpr(double x) {
//		return Math.tan(Math.toRadians(e.CalculerExpr(x))) * 100;
//	}

	public Expression getExpr() {
		return e;
	}

	@Override
	public Expression derivative() {
		return new DivExpression(
				e.derivative(), 
				new PowerExpression(
						new CosExpression(e), 
						new ConstantExpression(2.0)
						)
				) ;
	}

	@Override
	public double calculate(double value) {
		return Math.tan(value);
	}

}
