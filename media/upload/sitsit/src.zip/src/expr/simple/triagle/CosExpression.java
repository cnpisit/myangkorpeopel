package expr.simple.triagle;

import expr.Expression;
import expr.compound.binary.DivExpression;
import expr.compound.binary.MulExpression;
import expr.compound.binary.SubExpression;
import expr.simple.ConstantExpression;
import expr.simple.SimpleExpression;

public class CosExpression extends SimpleExpression{
    Expression e;
    public CosExpression(Expression e){
        this.e=e;
    }
    @Override
    public String toString(){
        return "cos("+e+")";
    }
    @Override
    public Expression simplify() {
        return new CosExpression(e.simplify());
    }

//    @Override
//    public double CalculerExpr(double x) {
//        return Math.cos(Math.toRadians(e.CalculerExpr(x)))*100;
//    }

//    @Override
//    public Expression getExpr() {
//        return e;
//    }

    @Override
    public Expression derivative() {
    	return new MulExpression(
    			new ConstantExpression(-1.0) , 
    			new MulExpression(
    					e.derivative(), 
    					new SinExpression(e)
    					)
    	) ;
    }
	@Override
	public double calculate(double value) {
		return Math.cos(value);
	}
    
}
