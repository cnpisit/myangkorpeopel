package expr.simple.triagle;

import expr.Expression;
import expr.compound.binary.MulExpression;
import expr.simple.SimpleExpression;


public class SinExpression extends SimpleExpression{
    Expression e;
    public SinExpression(Expression e){
        this.e=e;
    }
    @Override
    public String toString(){
        return "sin("+e+")";
    }
    @Override
    public Expression simplify() {
        return new SinExpression(e.simplify());
    }

//    @Override
//    public double CalculerExpr(double x) {
//        return Math.sin(Math.toRadians(e.CalculerExpr(x)))*100;
//    }

//    @Override
//    public Expression getExpr() {
//        return e;
//    }

    @Override
    public Expression derivative() {
        return new MulExpression(
        		e.derivative(), 
        		new CosExpression(e));
    }
	@Override
	public double calculate(double value) {
		return Math.sin(value);
	}
    
}
