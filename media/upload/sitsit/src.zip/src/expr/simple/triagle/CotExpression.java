package expr.simple.triagle;

import expr.Expression;
import expr.compound.binary.AddExpression;
import expr.compound.binary.DivExpression;
import expr.compound.binary.MulExpression;
import expr.compound.binary.PowerExpression;
import expr.compound.binary.SubExpression;
import expr.simple.ConstantExpression;
import expr.simple.SimpleExpression;

public class CotExpression extends SimpleExpression{
    Expression e;

    public CotExpression(Expression e) {
        this.e=e;
    }
    @Override
    public String toString(){
        return "cot("+e+")";
    }
    @Override
    public Expression simplify() {
        return new CotExpression(e.simplify());
    }

//    @Override
//    public double CalculerExpr(double x) {
//        return Math.atan(Math.toRadians(e.CalculerExpr(x)))*100;
//    }
//
//    @Override
//    public Expression getExpr() {
//        return e;
//    }

    @Override
    public Expression derivative() {
        return (new DivExpression(
				new ConstantExpression(1.0) ,
				new TanExpression(e)))
						.derivative() ;
    }
	@Override
	public double calculate(double value) {
		return (1.0/Math.tan(value)) ;
	}
    
}
