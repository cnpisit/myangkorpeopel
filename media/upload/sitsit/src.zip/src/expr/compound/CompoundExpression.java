package expr.compound;

import expr.Expression;

public abstract class CompoundExpression implements Expression {
	
}
