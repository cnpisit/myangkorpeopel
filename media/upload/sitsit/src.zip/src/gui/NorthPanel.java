package gui;

import imgs.Images;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class NorthPanel extends JPanel {
	
	private final Dimension DEAULT_SIZE = new Dimension(getWidth(), 80 ) ;
	private SolutionPanel solutionPanel = null ;
	private JTextField fAboveTextField = new JTextField() ;
	private JTextField fBelowTextField = new JTextField() ;
	
	public NorthPanel(SolutionPanel sp){
//		this.setBackground(Color.RED) ;
		this.setPreferredSize(DEAULT_SIZE) ;
		this.solutionPanel = sp ;
		
		this.setLayout(new BorderLayout()) ;
		
		this.add(
				new JLabel(
						new ImageIcon( Images.class.getResource("fx.png"))		
						)
				, BorderLayout.WEST) ;
//		JPanel fxPanel = new JPanel(new GridLayout(2, 1)) ;
//		fxPanel.add(fAboveTextField) ;
		
//		fxPanel.add(fBelowTextField) ;
		
//		this.add( fxPanel , BorderLayout.CENTER) ;
		this.add(fAboveTextField) ;
		
		JPanel buttonPanel = new JPanel() ;
		buttonPanel.setLayout(new GridLayout(2, 1)) ;
		JButton analyseButton = new JButton("Analyse") ;
		analyseButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String fx = NorthPanel.this.fAboveTextField.getText() ;
				
				NorthPanel.this.solutionPanel.setFxString( fx );
				NorthPanel.this.solutionPanel.initializeExpression() ;
				NorthPanel.this.solutionPanel.addAnalysisPanel() ;
			}
			
		}) ;
		
		JButton graphButton = new JButton("Graph");
		graphButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				NorthPanel.this.solutionPanel.addGraphPanel() ;
			}
			
		}) ;
		
		buttonPanel.add(analyseButton) ;
		buttonPanel.add(graphButton) ;
		
		
		
		this.add(buttonPanel , BorderLayout.EAST) ;
	}
}
