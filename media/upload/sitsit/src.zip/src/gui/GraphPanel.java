package gui;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;

import expr.Expression;

import math.Asymtote;

public class GraphPanel extends JPanel {
	public GraphPanel(){
		this.setBackground(Color.WHITE) ;
		this.add(new JLabel("<html><h1>Graph</h1></html>"));
		
		Asymtote a = new Asymtote() ;
		
		Expression asym = a.getAsym1() ;
	}
}
