package gui;

import imgs.Images;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class FunctionFrame extends JFrame {
	
	public static final Dimension DEFAULT_SIZE = new Dimension(840 , 520);
	
	private CenterPanel centerPanel = new CenterPanel() ;
	private NorthPanel nortPanel = new NorthPanel(centerPanel.getSolutionPanel()) ;
	private WestPanel westPanel = new WestPanel() ;
	
	private void initializeMenu(){
		JMenuBar menuBar = new JMenuBar() ;
		JMenu fileMenu = new JMenu("File") ;
		JMenu editMenu = new JMenu("Edit") ;
		
		JMenuItem openMenuItem  = new JMenuItem("open", 
				new ImageIcon(Images.class.getResource("open-folder.png"))) ;
		openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK)) ;
		
		openMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
//				System.out.println(e.toString());
				JFileChooser jfc = new JFileChooser() ;
				jfc.showOpenDialog(getParent()) ;
			}
		});
		
		JMenuItem exitMenuItem = new JMenuItem("exit", 
				new ImageIcon(Images.class.getResource("exit.png"))) ;
		exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK)) ;
		exitMenuItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FunctionFrame.this.dispose() ;
			}
		}) ;
		
		fileMenu.add(openMenuItem) ;
		fileMenu.add(exitMenuItem) ;
		
		menuBar.add(fileMenu) ;
		menuBar.add(editMenu) ;
		
		this.setJMenuBar(menuBar);
	}
	
	public FunctionFrame(String title){
		super(title) ;
		this.setSize(DEFAULT_SIZE) ;
		this.setMinimumSize(DEFAULT_SIZE) ;
		this.setLayout(new BorderLayout(5, 5)) ;
		this.setVisible(true);
		this.setLocation(getMidPoint()) ;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ;
		
		initializeMenu();
		
		this.add(nortPanel , BorderLayout.NORTH) ;
		this.add(westPanel , BorderLayout.WEST);
		this.add(centerPanel , BorderLayout.CENTER);
	}
	
	private Point getMidPoint() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();

		if (frameSize.height > screenSize.height) {
			frameSize.height = screenSize.height;
		}

		if (frameSize.width > screenSize.width) {
			frameSize.width = screenSize.width;
		}

		return new Point((screenSize.width - frameSize.width) / 3,
				(screenSize.height - frameSize.height) / 3);
	}

}
