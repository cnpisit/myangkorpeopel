package gui;

import java.awt.GridLayout;

import javax.swing.JPanel;

public class SolutionPanel extends JPanel {
	
	private String fxString = null ;
	private AnalysisPanel ananlysisPanel = new AnalysisPanel() ;
	private GraphPanel graphPanel = new GraphPanel() ;
	
	public void setFxString(String text) {
		this.fxString = text ;
		
	}
	
	public void initializeExpression(){
		ananlysisPanel.setExpression(fxString) ;		
	}
	
	public SolutionPanel(){
		this.setLayout(new GridLayout()) ;
		
	}
	
	public void addAnalysisPanel(){
		this.removeAll();
		ananlysisPanel.changeHTMLText() ;
		this.add(ananlysisPanel) ;
		
		doAfter() ;
	}
	
	public void removeAnalysisPanel(){ 
		//TODO
	}
	
	public void addGraphPanel(){
		this.removeAll();
		this.add(graphPanel) ;
		
		doAfter() ;
	}

	public void removeGraphPanel(){ 
		//TODO
//		this.graphPanel = null ;
		this.remove(graphPanel) ;
		
//		doAfter();
	}
	
	public void doAfter(){
		this.revalidate() ;
		this.repaint() ;
	}
}
