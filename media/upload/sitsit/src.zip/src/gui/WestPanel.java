package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class WestPanel extends JPanel {
	
	private final Dimension DEFAULT_SIZE = new Dimension(240, getHeight()) ;
	
	public WestPanel(){
//		this.setBackground(Color.CYAN) ;
		this.setPreferredSize(DEFAULT_SIZE);
		this.add(new CalButtonPanel()) ;
	}
}
