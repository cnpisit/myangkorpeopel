package gui.stylesheet;

import javax.swing.text.html.StyleSheet;

public class DefaultStylesSheet {
	public static StyleSheet initialDefaultStyleSheet(StyleSheet css){
		
		css.addRule("body { text-align : left; font-size: 2em; }");
		css.addRule("h1 { color : #00ff00; }");
		
		return css ;
	}
}
