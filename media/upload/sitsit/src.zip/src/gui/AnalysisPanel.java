package gui;

import expr.Expression;
import expr.simple.ConstantExpression;
import gui.stylesheet.DefaultStylesSheet;

import java.awt.GridLayout;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.StyleSheet;

import math.ExpressionTools;

import string.direction.DirectionString;
import string.domain.DomainString;
import string.graph.GraphString;

public class AnalysisPanel extends JPanel {
	
	private Expression expr = null ;
	private JEditorPane jep  = null ;

	public void setExpression(String s){
		this.expr = ExpressionTools.parseExpression(s) ;
	}
	
	
	private String iniHTML_String() {
		final int HTML_STRING_SIZE = string.Constant.STRING_BUFFER_MAX_CAPACITY ; // 100 KB
		StringBuffer html_string = new StringBuffer(HTML_STRING_SIZE) ;
		
		
		html_string.append("<html><head></head><body>") ;
		
		
		//Show fx
		html_string.append("<h2> f(x) = ") ;
		if( expr == null ){
			html_string.append( '0' ) ;
		}else{
			html_string.append( expr ) ;
		}
		html_string.append("</h2>") ;
		
		//Show derivative of fx
		html_string.append("<h2> f\'(x) = ") ;
		if( expr == null ){
			html_string.append( '0' ) ;
		}else{
			html_string.append( expr.derivative().simplify() ) ;
		}
		html_string.append("</h2>") ;

		html_string.append("<h1>1 - Domain</h1>" ) ;
		html_string.append(DomainString.addStringToDomain()) ;
		
		html_string.append("<h1>2 - Direction</h1>") ;
		html_string.append(DirectionString.addStringToDirection()) ;
		
		html_string.append("<h1>3 - Graph</h1>");
		html_string.append(GraphString.addStringToGraph()) ;

		html_string.append("</body></html>") ;

//		System.out.println("HTML");
		
		return html_string.toString() ;
	}
	
	private StyleSheet initializeStyleRule(HTMLEditorKit kit) {
		StyleSheet css = kit.getStyleSheet() ;
		css = DefaultStylesSheet.initialDefaultStyleSheet(css) ;
		return css ;
	}

	public AnalysisPanel() {
		this.setLayout(new GridLayout());

		jep = new JEditorPane();
		jep.setContentType("text/html; charset=UTF-8");
		
		HTMLEditorKit kit = new HTMLEditorKit();
		StyleSheet css = initializeStyleRule(kit) ;
		String html_string = iniHTML_String() ;

		jep.setEditorKit(kit);
		jep.setText(html_string);
		
		JScrollPane scroll = new JScrollPane(this) ;
		this.add(jep);
		
	}
	
	public void changeHTMLText(){
		String html_string = iniHTML_String() ;
		jep.setText(html_string);
	}
}
