package gui;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class CenterPanel extends JPanel {
	
	private SolutionPanel solutionPanel = new SolutionPanel() ;
	private JPanel navigation = new JPanel() ;
	
	private final String[] LIST = {
			"1 - Domain" ,
			"2 - Derivative" ,
			"  2 - 1 Derivative" ,
			"  2 - 2 Maximum and Minimum points" ,
			"  2 - 3 Change points" ,
			"  2 - 4 Limit" ,
			"  2 - 5 Asymptote" ,
			"  2 - 6 Variace table" ,
			"3 - Graph" ,
			"  3 - 1 Intersection" ,
			"  3 - 2 Symetry"
			
	} ;
	
	public CenterPanel(){
//		this.setBackground(Color.PINK) ;
		this.setLayout(new BorderLayout()) ;
		
		navigation.setLayout(new BorderLayout() ) ;
		
//		JComboBox<String> navComboBox = new JComboBox<String>( LIST ) ; //JDK 1.7
		JComboBox navComboBox = new JComboBox( LIST ) ; //JDK 1.6 or lower
		
//		navComboBox.setPreferredSize(new Dimension(340 , 32)) ;
		
		JButton prevButton =  new JButton("<") ;
		JButton nextButton =  new JButton(">") ;
		
		JPanel buttonPanel = new JPanel() ;
		buttonPanel.add(prevButton) ;
		buttonPanel.add(nextButton) ;
		
		navigation.add(navComboBox , BorderLayout.CENTER) ;
		navigation.add(buttonPanel , BorderLayout.EAST) ;
		
		
		this.add(navigation , BorderLayout.NORTH) ;

		JScrollPane jsp = new JScrollPane(solutionPanel) ;
		this.add(jsp) ;
	}
	
	public SolutionPanel getSolutionPanel(){
		return this.solutionPanel;
	}
}
