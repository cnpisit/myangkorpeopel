package gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class CalButtonPanel extends JPanel {
	
	private final Dimension DEFAULT_SIZE = new Dimension(getWidth(), 800) ;
	private final char[] SIGN = {'+' ,'-' ,'*' ,'/' ,'=' ,'^' ,'(' ,')' } ;
	private final String[] FUNS = {"sin" , "cos" , "tan" , "cot"} ;
	
	private JButton[] numsButtons = new JButton[10] ; // 0 1 2 3 4 5 6 7 8 9 
	private JButton[] signButtons = new JButton[SIGN.length] ;
	private JButton[] funsButtons = new JButton[FUNS.length] ;

	public CalButtonPanel(){

		this.setLayout(new GridLayout(6 , 4)) ;
		
		for(int i = 0 ; i<10 ; i++){
			numsButtons[i] = new JButton(String.valueOf(i)) ;
			numsButtons[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(getParent(), e.getActionCommand()) ;
				}
			}) ;
			
			this.add(numsButtons[i]) ;
		}
		
		for(int i = 0 ; i<SIGN.length ; i++){
			signButtons[i] = new JButton(String.valueOf(SIGN[i])) ;
			signButtons[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(getParent(), e.getActionCommand()) ;
				}
			}) ;
			
			this.add(signButtons[i]) ;
		}
		
		for(int i = 0 ; i<FUNS.length ; i++){
			funsButtons[i] = new JButton(String.valueOf(FUNS[i])) ;
			funsButtons[i].addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(getParent(), e.getActionCommand()) ;
				}
			}) ;
			
			this.add(funsButtons[i]) ;
		}
		
//		for(char s : SIGN){
//			this.add(new JButton(String.valueOf(s))) ;
//		}
//		
//		for(String s : FUNS){
//			this.add(new JButton(String.valueOf(s))) ;
//		}
	}
}
